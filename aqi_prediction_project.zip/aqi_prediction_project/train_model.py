from pathlib import Path
import joblib
import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from sklearn.model_selection import train_test_split

DATA_PATH = Path("aqi_demo_data.csv")
MODEL_PATH = Path("aqi_model.joblib")

FEATURES = [
    "PM2_5", "PM10", "NO2", "SO2", "CO", "O3",
    "temperature_C", "humidity_pct",
]
TARGET = "AQI"

if not DATA_PATH.exists():
    raise FileNotFoundError(
        "aqi_demo_data.csv not found. Run: python generate_demo_data.py"
    )

df = pd.read_csv(DATA_PATH)
required = FEATURES + [TARGET]
missing = [col for col in required if col not in df.columns]
if missing:
    raise ValueError(f"Dataset is missing required columns: {missing}")

df = df[required].apply(pd.to_numeric, errors="coerce").dropna()
if len(df) < 30:
    raise ValueError("Need at least 30 complete rows to run this demo.")

X = df[FEATURES]
y = df[TARGET]
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42
)

model = RandomForestRegressor(
    n_estimators=250, random_state=42, min_samples_leaf=2, n_jobs=-1
)
model.fit(X_train, y_train)
predictions = model.predict(X_test)

mae = mean_absolute_error(y_test, predictions)
rmse = np.sqrt(mean_squared_error(y_test, predictions))
r2 = r2_score(y_test, predictions)

joblib.dump({"model": model, "features": FEATURES}, MODEL_PATH)
print("Model training complete.")
print(f"Rows used: {len(df)}")
print(f"MAE:  {mae:.2f}")
print(f"RMSE: {rmse:.2f}")
print(f"R²:   {r2:.3f}")
print(f"Saved model to: {MODEL_PATH}")
print("Reminder: metrics are from synthetic demo data, not real-world performance.")
