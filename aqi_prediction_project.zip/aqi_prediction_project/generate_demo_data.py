import numpy as np
import pandas as pd

# Synthetic data for demonstrating the project workflow only.
# It is NOT measured environmental data and should not be used for decisions.
rng = np.random.default_rng(42)
n = 1200

pm25 = rng.gamma(shape=2.2, scale=18, size=n).clip(1, 300)
pm10 = (pm25 * rng.uniform(1.1, 2.2, n) + rng.normal(0, 12, n)).clip(5, 500)
no2 = rng.gamma(shape=2.0, scale=12, size=n).clip(1, 200)
so2 = rng.gamma(shape=1.8, scale=5, size=n).clip(0.5, 100)
co = rng.gamma(shape=2.0, scale=0.45, size=n).clip(0.1, 15)
o3 = rng.gamma(shape=2.0, scale=18, size=n).clip(1, 220)
temperature = rng.normal(28, 6, n).clip(5, 48)
humidity = rng.normal(58, 18, n).clip(10, 100)

# Artificial target solely to make a runnable demo. Not an official AQI formula.
aqi = (
    1.15 * pm25 + 0.22 * pm10 + 0.35 * no2 + 0.45 * so2
    + 2.8 * co + 0.18 * o3 + rng.normal(0, 12, n)
).clip(0, 500)

df = pd.DataFrame({
    "PM2_5": pm25.round(2),
    "PM10": pm10.round(2),
    "NO2": no2.round(2),
    "SO2": so2.round(2),
    "CO": co.round(2),
    "O3": o3.round(2),
    "temperature_C": temperature.round(2),
    "humidity_pct": humidity.round(2),
    "AQI": aqi.round(2),
})
df.to_csv("aqi_demo_data.csv", index=False)
print(f"Created aqi_demo_data.csv with {len(df)} synthetic demo rows.")
