# Air Quality Index (AQI) Prediction Using Environmental Data

A beginner-friendly machine-learning project that trains a Random Forest regression model and provides an interactive Streamlit dashboard.

## Important note about the included dataset
`aqi_demo_data.csv` is **synthetic demonstration data**, generated for learning and testing the project workflow. It is not real monitoring-station data and must not be used for health or environmental decisions. For a real project, replace it with verified historical observations from a trusted source and document the source, units, location, and time period.

## Requirements
- Python 3.10 or newer recommended
- pip

## Setup (Windows / VS Code)
Open Command Prompt in this folder and run:

```bash
python -m venv .venv
.venv\Scripts\activate
python -m pip install --upgrade pip
pip install -r requirements.txt
```

## Train the model
```bash
python train_model.py
```
This creates `aqi_model.joblib` and prints MAE, RMSE, and R² on a held-out test set.

## Run the dashboard
```bash
streamlit run app.py
```
Open the local URL Streamlit prints (usually http://localhost:8501).

## Dataset columns
- `PM2_5`, `PM10`, `NO2`, `SO2`, `CO`, `O3`: pollutant measurements
- `temperature_C`: temperature in Celsius
- `humidity_pct`: relative humidity percentage
- `AQI`: demonstration target value

The demo data uses arbitrary generated relationships to illustrate regression. The model's scores on synthetic data do not represent real-world predictive performance.

## Next improvements
1. Replace synthetic data with a real, documented dataset.
2. Confirm units and AQI calculation standard for the selected country.
3. Use time-aware train/test splits if predicting future AQI from time series.
4. Compare multiple models and check for data leakage.
5. For forecasting, include timestamps and past pollutant/AQI observations.
